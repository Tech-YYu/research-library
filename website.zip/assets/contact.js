// The recipient address belongs in the form provider's private dashboard only.
const form = document.getElementById('contact-form');
if (form) {
  const button = form.querySelector('button[type="submit"]');
  const status = document.getElementById('contact-status');
  const configured = /^https:\/\/formspree\.io\/f\/[a-z0-9]+$/i.test(form.getAttribute('action') || '');
  const reset = () => {
    button.disabled = !configured;
    button.innerHTML = 'Send message <span aria-hidden="true">↗</span>';
    status.textContent = configured ? '' : 'Preview — email delivery is awaiting connection.';
  };
  reset();
  // A normal POST preserves Formspree's hosted spam checks and confirmation.
  form.addEventListener('submit', event => {
    if (!configured) {
      event.preventDefault();
      return;
    }
    button.disabled = true;
    button.textContent = 'Sending…';
    status.textContent = 'Opening the secure submission page…';
  });
  window.addEventListener('pageshow', reset);
}

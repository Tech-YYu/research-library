export const TYPES = {
  all: {label:'All resources', description:'Primary sources, concise summaries and practical details for reuse.'},
  dataset: {label:'Datasets & traces', description:'Workload telemetry and measured power, with measurement boundaries and temporal resolution kept explicit.'},
  model: {label:'Simulation models', description:'EMT, phasor and workload simulation resources. Check the implementation, license and validation scope before use.'},
  publication: {label:'Publications', description:'Research on computing workloads, power demand, scheduling and electrical behaviour.'},
  industry: {label:'Industry & technology', description:'Architecture references, technical reports and industry perspectives on power delivery and cooling.'},
  regulation: {label:'Standards & policy', description:'Grid connection, reporting and reliability resources. Jurisdiction and document status matter; proposals are labelled separately.'}
};
export function filterRecords(records, state, saved = new Set()) {
  const words = (state.q || '').trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  const rows = records.filter(r => {
    if(state.view === 'saved' && !saved.has(r.id)) return false;
    if(state.type !== 'all' && r.type !== state.type) return false;
    if(state.topic && !r.topics.includes(state.topic)) return false;
    if(state.region && r.region !== state.region) return false;
    if(state.power && (r.type !== 'dataset' || r.power !== state.power)) return false;
    const searchable = [r.title,r.organization,r.summary,r.limitation,r.status,r.region,r.platform,r.boundary,r.resolution,...r.topics].join(' ').toLocaleLowerCase();
    return words.every(word => searchable.includes(word));
  });
  if(state.sort === 'newest') rows.sort((a,b)=>(b.year||0)-(a.year||0)||a.title.localeCompare(b.title));
  else if(state.sort === 'title') rows.sort((a,b)=>a.title.localeCompare(b.title));
  return rows;
}
export function citation(r) { return `${r.organization}. ${r.year ? `(${r.year}). ` : ''}${r.title}. ${r.url} (source checked ${r.reviewed}).`; }
const bibEscape = value => String(value ?? '').replace(/\\/g,'\\textbackslash{}').replace(/[&%#_]/g,'\\$&').replace(/[{}]/g, match => '\\'+match);
export function toBibTeX(rows) {
  return rows.map(r => `@misc{${r.id.replace(/[^a-zA-Z0-9_-]/g,'')},\n  title = {${bibEscape(r.title)}},\n  howpublished = {${bibEscape(r.organization)}},${r.year ? `\n  year = {${r.year}},` : ''}\n  url = {${r.url}},\n  note = {${bibEscape(r.status)}; source checked ${r.reviewed}}\n}`).join('\n\n');
}
export function toCSV(rows) {
  const keys=['id','title','type','organization','year','status','region','power','boundary','resolution','platform','summary','limitation','topics','url','reviewed'];
  const cell = v => {const t=Array.isArray(v)?v.join('; '):String(v??'');return '"'+(/^[=+@\-]/.test(t)?"'"+t:t).replace(/"/g,'""')+'"';};
  return [keys,...rows.map(r=>keys.map(k=>r[k]))].map(row=>row.map(cell).join(',')).join('\r\n');
}
